----------Nightmare on Kluyverweg----------
This entry was made by Maria Beisert and Tom Gacek.

----------How to run----------
Using the terminal, navigate into the scripts folder and run main.py.
If this file is run from the wrong folder the game will not start.

----------Credits----------
Sound effects:
https://pixabay.com/music/mystery-ghost-10358/
https://freesound.org/people/original_sound/sounds/366103/
https://freesound.org/people/TitanKaempfer/sounds/689902/
https://freesound.org/people/MLaudio/sounds/615099/
